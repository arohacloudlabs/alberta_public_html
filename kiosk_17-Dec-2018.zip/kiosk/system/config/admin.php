<?php
// Site
$_['site_base']         = substr(HTTP_SERVER, 7);
$_['site_ssl']          = true;

// Database
$_['db_autostart']      = true;
$_['db_type']           = DB_DRIVER; // mpdo, mssql, mysql, mysqli or postgre
$_['db_hostname']       = DB_HOSTNAME;
$_['db_username']       = DB_USERNAME;
$_['db_password']       = DB_PASSWORD;
$_['db_database']       = DB_DATABASE;
$_['db_port']           = DB_PORT;

$_['db_database2']       = '';

//$_['db_type2']           = DB_DRIVER2; // mpdo, mssql, mysql, mysqli or postgre
//$_['db_hostname2']       = DB_HOSTNAME2;
//$_['db_username2']       = DB_USERNAME2;
//$_['db_password2']       = DB_PASSWORD2;
//$_['db_database2']       = '';
//$_['db_port2']           = DB_PORT2;


// Session
$_['session_autostart'] = true;

// Actions
$_['action_pre_action']  = array(
	'startup/startup',
	'startup/error',
	'startup/event',
	'startup/sass',
	'startup/login',
	'startup/permission'
);

// Actions
$_['action_default']     = 'common/dashboard';

// Action Events
$_['action_event'] = array(
    'view/*/before' => 'event/theme',
);