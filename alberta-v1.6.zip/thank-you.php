<?php include "includes/header.php"; ?>

<body onLoad="setTimeout('go_now()', 3000)">
<h1 class="text-center py-7">Thank you for contacting us.</h1>

<script language="JavaScript">
  function go_now () {
      window.location.href = "http://albertapayments.com";
  }
  
  </script>
</body>


<?php include "includes/footer.php"; ?>
