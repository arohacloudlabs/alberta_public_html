<?php
// HTTP
define('HTTP_SERVER', 'http://kiosk.insloc.com/');
define('HTTP_CATALOG', 'http://kiosk.insloc.com/');

// HTTPS
define('HTTPS_SERVER', 'https://kiosk.insloc.com/');
define('HTTPS_CATALOG', 'https://kiosk.insloc.com/');

define('DOMAIN','kiosk');

// DIR
define('DIR_APPLICATION', 'public_html/kiosk/');
define('DIR_SYSTEM', 'public_html/kiosk/system/');
define('DIR_IMAGE', 'public_html/kiosk/image/');
define('DIR_LANGUAGE', 'public_html/kiosk/language/');
define('DIR_TEMPLATE', 'public_html/kiosk/view/template/');
define('DIR_CONFIG', 'public_html/kiosk/system/config/');
define('DIR_CACHE', 'public_html/kiosk/system/storage/cache/');
define('DIR_DOWNLOAD', 'public_html/kiosk/system/storage/download/');
define('DIR_LOGS', 'public_html/kiosk/system/storage/logs/');
define('DIR_MODIFICATION', 'public_html/kiosk/system/storage/modification/');
define('DIR_UPLOAD', 'public_html/kiosk/system/storage/upload/');
define('DIR_CATALOG', 'public_html/kiosk/catalog/');

// DB
define('DB_DRIVER', '');
define('DB_HOSTNAME', '');
define('DB_USERNAME', '');
define('DB_PASSWORD', '');
define('DB_DATABASE', '');
define('DB_PORT', '');
define('DB_PREFIX', '');