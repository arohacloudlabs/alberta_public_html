<?php
// Heading
$_['heading_title']          = 'Table Action';

// Text
$_['text_success']           = 'Success: You have exported Tables!';
$_['text_list']              = 'Table List';
$_['text_default']           = 'Default';


$_['entry_keyword']          = 'SEO URL';
$_['entry_parent']           = 'Parent';
$_['entry_filter']           = 'Filters';
$_['entry_store']            = 'Stores';


// Error
$_['error_warning']          = 'Warning: Please check the form carefully for errors!';
$_['error_permission']       = 'Warning: You do not have permission to modify table action!';

